﻿namespace Zoo
{
    class Lizard : Reptile
    {
        public Lizard(string name)
            :base(name)
        {                
        }
    }
}
